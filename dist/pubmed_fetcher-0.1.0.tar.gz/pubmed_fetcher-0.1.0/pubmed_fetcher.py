import requests

def fetch_papers(query: str):
    url = f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
    params = {
        "db": "pubmed",
        "term": query,
        "retmode": "json",
        "retmax": 5
    }
    
    response = requests.get(url, params=params)
    
    if response.status_code == 200:
        data = response.json()
        paper_ids = data.get("esearchresult", {}).get("idlist", [])
        print(f"Found {len(paper_ids)} papers:")
        print(paper_ids)
        return paper_ids
    else:
        print(f"Error: {response.status_code} - {response.text}")
        return []

def fetch_paper_details(paper_id: str):
    url = f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi"
    params = {
        "db": "pubmed",
        "id": paper_id,
        "retmode": "json"
    }
    
    response = requests.get(url, params=params)
    
    if response.status_code == 200:
        data = response.json()
        result = data.get("result", {}).get(paper_id, {})
        
        # Debugging print
        print(result) 
        
        title = result.get("title", "N/A")
        pub_date = result.get("pubdate", "N/A")
        
        # ✅ Extract author names correctly
        authors = [author.get('name', '') for author in result.get('authors', [])]

        # ✅ Filter out AI-related authors properly
        academic_authors = [
            author for author in authors
            if isinstance(author, str) and not any(x in author.lower() for x in ['gpt', 'gemini', 'ai'])
        ]

        if academic_authors:
            print(f"Title: {title}")
            print(f"Publication Date: {pub_date}")
            print(f"Authors: {', '.join(academic_authors)}")
            print("-" * 50)
        else:
            print(f"Skipping non-academic paper: {title}")
    else:
        print(f"Failed to fetch details for paper ID {paper_id}")





if __name__ == "__main__":
    query = input("Enter search query: ")
    paper_ids = fetch_papers(query)
    
    if paper_ids:
        print("\nFetching details for each paper...\n")
        for paper_id in paper_ids:
            fetch_paper_details(paper_id)  # Ensure this line is properly indented!
