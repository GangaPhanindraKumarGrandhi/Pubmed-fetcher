# PubMed Fetcher

A Flask-based API to fetch PubMed research papers using Biopython.

## 🚀 Installation
1. Clone the repository.
2. Install dependencies using `poetry install`.
3. Start the server using `poetry run python app.py`.

## 🚀 Endpoints
- `/search?query=cancer` - Search papers
- `/papers` - Export papers to CSV
- `/export/json` - Export papers to JSON
- `/export/csv` - Export papers to CSV
- `/paper/<paper_id>` - Get paper details by ID
- `/test_fetch` - Test fetch papers
